;(function(){

angular.module('riceBookApp')
	.factory('api', apiService)
	;

// ng-repeat = "post in post track by $index"

// <div> {{ post }} </div>
// <button ng-click = "vm.addComment($index)"></button>
// ///
// ///
// vm.addComment = function($index){
// 	apiService.addComment({id:$index, body: , commentid: -1})
// }


// apiService.addComment({id:v, body:"dfajdfkajkjdklfjakl", id:"-1"}).$promise

function apiService($http, $resource, apiURL) {
    $http.defaults.withCredentials = true;
	return $resource(apiURL + '/:endpoint/:user', {  }, 
		{
            login    : { method:'POST', params: {endpoint: 'login'  } },
            logout   : { method: 'PUT' , params: {endpoint: 'logout'  } },
			getStatus: { method:'GET', params: {endpoint: 'statuses'} },
			setStatus: { method:'PUT', params: {endpoint: 'status'} },
			getAvatar: { method: 'GET', params:{endpoint: 'pictures'}},
			getPosts : { method:'GET', params: {endpoint: 'posts' } },
			addPost  : { method:'POST', params: {endpoint: 'post' } },
			changeComment: {method: 'PUT', params:{endpoint: 'posts/3089592'}},
			// change a post
			// add comment
			// change comment
			getEmail : { method:'GET', params: {endpoint: 'email' } },
			
		});
}
})();
