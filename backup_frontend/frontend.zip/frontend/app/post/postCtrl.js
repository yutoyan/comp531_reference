;(function(){

angular.module('riceBookApp')
	.controller('PostCtrl', PostCtrl)
	;

PostCtrl.$inject = ['$http', 'api', 'UserService'];
function PostCtrl($http, api, UserService) {
	var vm = this;
	vm.loadPosts = loadPosts;
	vm.posts = [];
	loadPosts();
	vm.removePost = removePost;
 
	vm.newPost = "";
	vm.addPost = addPost;
	vm.newComment = ""
	vm.addComment = addComment;

	//*********** functions ******************//

	function loadPosts() {
		vm.posts = [];
		api.getPosts().$promise.then(function(result) {
			result.posts.forEach(function(post) {
				
				post.date = post.date.substr(0,10) + ' ' + post.date.substr(11,8);
				post.comments.forEach(function(comment){
					comment.date = comment.date.substr(0,10) + ' ' + comment.date.substr(11,8);});
				
				vm.posts.push(post);
			});
		});
	}

	function removePost(postId) {
        var index = vm.posts.findIndex(function(post) { 
             return post.id === postId; 
        }); 
        if (index >= 0) { 
             vm.posts.splice(index, 1); 
        } 
	}

	function addPost(){
		console.log("new post will be added: ", vm.newPost);
		api.addPost({'body':vm.newPost})
             .$promise.then(function(result) {
                   console.log('Payload from server:', result);
                   vm.loadPosts();
                   vm.newPost = "";
             });
	}
	function addComment(posstID){
		console.log("new comment will be added: ", vm.newComment);
		api.changeComment({'body':vm.newComment, 'commentId': -1})
             .$promise.then(function(result) {
                   console.log('Payload from server for comments adding:', result);
                   vm.loadPosts();
                   vm.newPost = "";
                   vm.newComment = "";
             });
	}

}
})();
