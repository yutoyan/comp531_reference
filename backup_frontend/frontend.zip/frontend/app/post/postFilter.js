(function(){
angular.module('riceBookApp')
.filter("selectiveFilter",selectiveFilter);

function selectiveFilter(){	
	return function(cards, keys){
		if(!keys){
			return cards;
		}
		var output = [];
		var searchKeyword = keys.toLowerCase();

		angular.forEach(cards, function(card){
			if(card.poster.toLowerCase().match(searchKeyword) !== null || card.body.toLowerCase().match(searchKeyword) !== null){
				output.push(card);
			}
		});
		return output;
	};
}
})();