(function(){

angular.module('riceBookApp')
.controller('MainPageCtrl', MainPageCtrl);

MainPageCtrl.$inject = ['$http', 'api', '$location', 'UserService'];
function MainPageCtrl($http, api, $location, UserService) {

	var vm = this;
    vm.logout = logout;

    function logout() {
         api.logout();
         // vm.username = ''
         // vm.userStatus =''
         // vm.newUserStatus =''
         // vm.loggedIn = false
         // vm.loc = { }
         // 
         // Clear the UserService singleton's username value
		 UserService.username = null;
		 $location.path('/');
    }
} 
})();