(function(){

angular.module('riceBookApp')
.controller('StatusCtrl',StatusCtrl);

StatusCtrl.$inject = ['$http','api', 'UserService'];
function StatusCtrl($http, api, UserService) {

	var vm = this;
	vm.getUsername = getUsername;
	vm.setStatus = setStatus;
	vm.username = getUsername();
	vm.status = getStatus();
	vm.avatar = getAvatar();
	console.log("on status, username: ",vm.username);
	console.log("on status, avatar: ",vm.avatar);

	// getStatus();
	// getUsername();

	
	//*********** functions ******************//
	
	function getUsername() {
		//return the username from the UserService
		return UserService.username;
	}
	function getAvatar() {
		//return the avatar from the UserService
		return UserService.avatar;
	}

	function getStatus() {
		api.getStatus().$promise.then(function(result) {
			vm.status = result.statuses[0].status;
			vm.newStatus = vm.status;
		});
	}

	function setStatus() {
		api.setStatus({ status: vm.newStatus}).$promise.
		then(function(result) {
            console.log(result);
			vm.status = result.status;
			vm.newStatus = vm.status;
		});
	}

	// function getAvatar(){
	// 	api.getAvatar().$promise.
	// 	then(function(result) {
 //            console.log("getAvatar",result);
	// 		vm.avatar = result.pictures[0].picture;
			
	// 	});

	// }

	

} 




})();