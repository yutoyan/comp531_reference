// It contain stubs for authorization functionality.
exports.setup = function (app) {
    app.post('/login', login);
    app.put('/logout', logout);
    app.post('/register', register);
    app.put('/password', setPassword);
};

function login() {
    var username = req.body.username ? req.body.username : "defaultTestUser";
    return {
        "username": username,
        "result": "success"
    }
}

function logout() {
    return "OK"
}

function register() {
    var username = req.body.username ? req.body.username : "newUser";
    return {
        "result": "success",
        "username": username
    }

}

function setPassword() {
    var username = req.user ? req.user : "defaultTestUser";
    return {
        "username": username,
        "status": "will not change"
    }
}