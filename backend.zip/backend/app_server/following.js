// It contain stubs for following functionality.
exports.setup = function (app) {
    app.get('/following/:user*?', getFollowings);
    app.put('/following/:user', addFollowing);
    app.delete('/following/:user', removeFollowing);
};

var _followings = {};

function getFollowings() {
    var username = req.params.user ? req.params.user.split(',')[0] : (req.user ? req.user : "defaultTestUser");
    if (!_followings[username]) {
        _followings[username] = ["following_1", "following_2", "following_3"]
    }
    return {"username": username, "followings": _followings[username]}
}

function addFollowing() {
    var loggedInUser = req.user ? req.user : "defaultTestUser";
    var toBeAddFollowing = req.params.user ? req.params.user.split(',')[0] : "newlyAddedFollowing";
    if (!_followings[loggedInUser]) {
        _followings[loggedInUser] = ["following_1", "following_2", "following_3"]
    }
    // Add new following.
    _followings[loggedInUser].push(toBeAddFollowing);

    return {"username": loggedInUser, "followings": _followings[loggedInUser]}
}

function removeFollowing() {
    var loggedInUser = req.user ? req.user : "defaultTestUser";
    var toBeRemoveFollowing = req.params.user ? req.params.user.split(',')[0] : "newlyRemovedFollowing";
    if (!_followings[loggedInUser]) {
        _followings[loggedInUser] = ["following_1", "following_2", "following_3"]
    }
    // Do nothing to the existing following list. Just a stub.
    return {"username": loggedInUser, "followings": _followings[loggedInUser]}

}

